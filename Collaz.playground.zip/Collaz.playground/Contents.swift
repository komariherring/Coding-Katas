import UIKit
var numberOfSteps = 0


func getSeedNumber(seedNumber: Int)

{
    var newValue: Int
    if seedNumber == 1
    {
        newValue = seedNumber
    }
    
    else if seedNumber % 2 == 0
    
    {
        newValue = seedNumber/2
    }
    else
    
    {
        newValue = (3 * seedNumber) + 1
    }
    
    numberOfSteps = numberOfSteps + 1
    
    print("Step \(numberOfSteps) -> \(newValue)")
    
    secondNumber(aSeedNumber: newValue)
    
}



func secondNumber(aSeedNumber: Int)

{
    if aSeedNumber == 1
    {
        print("There is a \(aSeedNumber) and it took \(numberOfSteps) steps.")
    }
    else
    {
        getSeedNumber(seedNumber: aSeedNumber)
    }
    
}

//go back and make print statement





